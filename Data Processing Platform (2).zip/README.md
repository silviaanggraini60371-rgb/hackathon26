
  # Data Processing Platform

  This is a code bundle for Data Processing Platform. The original project is available at https://www.figma.com/design/oSsHgf1loLalnxiDE3q7RM/Data-Processing-Platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  